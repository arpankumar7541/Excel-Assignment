create database SAITM;
use SAITM;
create table students(sid int primary key, sname varchar(30),
 age int, phone bigint);
insert into students values(101,'Aman Mishra', 19, 965478058),
(102,'shon Mishra', 29, 965478058),(103,'Mishra', 26, 965478058);
select * from students;
update students set sname='rohan sharma' where sid=103;
delete from students where sid=103;
alter table students add fees double;
update students set fees=2400 where sid=101;